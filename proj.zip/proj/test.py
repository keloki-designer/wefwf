import os
import csv

def load_prices():
    directory = "101/" # здесь указано название папки которую будет сканированть на наличие цен
    data=[] # список куда будет добавлено содержимое всех прайс листов

    for file in os.listdir(directory): # заходит в папку и берет каждый файл поочереди

        if file.startswith("price_") and file.endswith(".csv"):# если название файла начинается с price и имеет расширение csv то

            file_path = os.path.join(directory, file)
            with open(file_path, 'r', encoding='utf-8') as f: # то этот файл будет открыт а цикл пройдет по всем его строкам, напишет их на экран и сохранит в список

                for row in f:
                    print(row)
                    data.append(row)
    return data

print(load_prices())